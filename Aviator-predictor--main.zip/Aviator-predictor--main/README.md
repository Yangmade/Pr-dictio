aviator predictor
